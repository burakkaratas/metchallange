package com.hotelspro.challange.burak.karatas.controllers.exceptions;

/**
 * Created by bkaratas on 5/8/17.
 */
public class BusinessException extends Exception {

    public BusinessException(String exceptionMessage) {
        super(exceptionMessage);
    }
}
