package com.hotelspro.challange.burak.karatas.services;

import java.util.List;

/**
 * Created by bkaratas on 05.05.2017.
 */
public interface ICalculator {

    Double process(Double param1, Double param2);

}
