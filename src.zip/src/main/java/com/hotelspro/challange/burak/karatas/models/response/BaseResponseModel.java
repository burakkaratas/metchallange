package com.hotelspro.challange.burak.karatas.models.response;

import java.util.Date;

/**
 * Created by bkaratas on 05.05.2017.
 */
public class BaseResponseModel {
}
