package com.hotelspro.challange.burak.karatas.models.response;

/**
 * Created by bkaratas on 05.05.2017.
 */
public class CalculatorResponseBody extends BaseResponseModel {

}
